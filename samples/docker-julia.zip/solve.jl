using JSON

function cover_tasks(workers, site_tasks)
    need = Set(site_tasks)
    isempty(need) && return Int[]
    chosen = Int[]
    used = Set{Int}()
    while !isempty(need)
        found = -1
        for (wid, skills) in enumerate(workers)
            wid in used && continue
            skillset = Set(skills)
            if any(task -> task in skillset, need)
                found = wid
                break
            end
        end
        if found < 1
            return nothing
        end
        push!(chosen, found - 1)  # 0-based worker id in JSON
        push!(used, found)
        for skill in workers[found]
            delete!(need, skill)
        end
    end
    return sort(chosen)
end

function minimal_solution(instance)
    sites = get(instance, "sites", [])
    offices = get(instance, "offices", [])
    workers = get(instance, "workers", [])
    (isempty(sites) || isempty(offices)) && return []
    max_size = get(getindex(offices, 1), "maxSize", 0)
    max_size < 1 && return []
    for site_id in 0:(length(sites) - 1)
        site = sites[site_id + 1]
        tasks = get(site, "tasks", Int[])
        picked = cover_tasks(workers, tasks)
        picked === nothing && continue
        return [Dict("officeId" => 0, "sites" => [site_id], "workers" => picked)]
    end
    return []
end

function read_instance(path::AbstractString)
    text = read(path, String)
    if startswith(text, "\ufeff")
        text = text[2:end]
    end
    return JSON.parse(text)
end

function main()
    input = length(ARGS) >= 1 ? ARGS[1] : "instance.json"
    output = length(ARGS) >= 2 ? ARGS[2] : "solution.json"
    instance = read_instance(input)
    solution = minimal_solution(instance)
    open(output, "w") do io
        JSON.print(io, solution, 2)
        println(io)
    end
end

main()
